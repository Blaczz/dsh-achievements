# Task 17 — P6.4 七条核心 Milestone Chains + 30 个新成就

| 字段 | 内容 |
|---|---|
| 优先级 | **P6.4 / 核心内容扩展** |
| 前置依赖 | Task 16 |
| 核心目标 | 把 7 个 Lifetime 指标扩成完整的五级成长线，共新增 30 个 Built-in Achievement |
| 目标总数 | **18 → 48** |
| 风险 | 中（目录一致性、旧 ID 兼容） |
| 主要文件 | `src/achievements.ts`, `src/share.ts`, achievement/share tests |

## 1. 目录总原则

每条正式 progression chain 必须：

1. 恰好 5 个节点；
2. threshold 严格递增；
3. rarity 恰好依次为：

```text
common → uncommon → rare → epic → legendary
```

4. 所有节点 `scope = 'lifetime'`；
5. 所有节点提供 progress/target；
6. 旧 ID / threshold / rarity / XP 不改。

## 2. 完整目录

### A. 回合之路 / Turns

正式 chain：

| Rarity | ID | 图标 | 中文标题 | English | Target | XP | 状态 |
|---|---|---|---|---|---:|---:|---|
| common | `first-turn` | 🎬 | 初次登场 | First Turn | 1 | 10 | **现有，保持** |
| uncommon | `turns-25` | 🚶 | 稳步前行 | Finding Rhythm | 25 | 30 | 新增 |
| rare | `turns-50` | 🧭 | 驾轻就熟 | In the Groove | 50 | 75 | 新增 |
| epic | `hundred-turns` | 💯 | 百炼成钢 | Century Club | 100 | 200 | **现有，保持** |
| legendary | `turns-500` | 👑 | 回合宗师 | Turnmaster | 500 | 400 | 新增 |

建议 description：

```text
累计完成 N 个回合 / Complete N turns
```

`ten-turns`（10 回合、common、20 XP）继续保留，但作为额外早期里程碑，不进入正式五级 chain。

### B. 工具之途 / Tool Path

| Rarity | ID | 图标 | 中文标题 | English | Target | XP | 状态 |
|---|---|---|---|---|---:|---:|---|
| common | `first-tool` | 🔧 | 工具初体验 | Tool Time | 1 | 10 | **现有，保持** |
| uncommon | `tools-25` | 🧰 | 工具箱常客 | Toolbox Regular | 25 | 30 | 新增 |
| rare | `hundred-tools` | 🛠️ | 工具大师 | Power Tooler | 100 | 150 | **现有，保持** |
| epic | `tools-500` | ⚙️ | 机巧工坊 | Toolsmith | 500 | 175 | 新增 |
| legendary | `tools-2000` | 🦾 | 万能机巧 | Master of Tools | 2000 | 400 | 新增 |

指标：`profile.toolCalls`。

### C. 会话旅程 / Sessions

| Rarity | ID | 图标 | 中文标题 | English | Target | XP | 状态 |
|---|---|---|---|---|---:|---:|---|
| common | `sessions-1` | 💬 | 初次会面 | First Session | 1 | 10 | 新增 |
| uncommon | `ten-sessions` | 📚 | 会话收藏家 | Session Collector | 10 | 50 | **现有，保持** |
| rare | `sessions-50` | 🗂️ | 会话常客 | Session Regular | 50 | 75 | 新增 |
| epic | `sessions-200` | 🧳 | 长谈不倦 | Conversation Veteran | 200 | 175 | 新增 |
| legendary | `sessions-500` | 🏛️ | 会话典藏家 | Session Archivist | 500 | 400 | 新增 |

指标：`profile.sessions`。

注意当前 `sessions` 的语义是“完成至少一个 turn 的 distinct session id”，保持不变。

### D. 活跃岁月 / Active Days

| Rarity | ID | 图标 | 中文标题 | English | Target | XP |
|---|---|---|---|---|---:|---:|
| common | `active-days-1` | 🌅 | 今日启程 | Day One | 1 | 10 |
| uncommon | `active-days-7` | 📅 | 一周常驻 | One Week In | 7 | 30 |
| rare | `active-days-30` | 🗓️ | 月度常客 | Month Regular | 30 | 75 |
| epic | `active-days-100` | 🌤️ | 百日同行 | Hundred Days | 100 | 175 |
| legendary | `active-days-365` | 🌍 | 周年相伴 | Year in the Loop | 365 | 400 |

指标：`profile.activeDays`。

现有：

```text
streak-3
streak-7
```

继续作为“连续作战”特殊 chain，不能替代累计活跃天数。

### E. 阅读之路 / File Reads

| Rarity | ID | 图标 | 中文标题 | English | Target | XP |
|---|---|---|---|---|---:|---:|
| common | `file-reads-10` | 📖 | 翻阅初章 | First Chapter | 10 | 10 |
| uncommon | `file-reads-100` | 📚 | 广泛阅读 | Wide Reader | 100 | 30 |
| rare | `file-reads-500` | 🧠 | 仓库漫游者 | Repository Rover | 500 | 75 |
| epic | `file-reads-2500` | 🔬 | 源码博览家 | Source Scholar | 2500 | 175 |
| legendary | `file-reads-10000` | 🏯 | 万卷代码 | Ten Thousand Reads | 10000 | 400 |

指标：`profile.fileReads`，统计成功 read invocation 次数，不是 unique path。

### F. 编辑之路 / File Edits

| Rarity | ID | 图标 | 中文标题 | English | Target | XP |
|---|---|---|---|---|---:|---:|
| common | `file-edits-1` | ✏️ | 落下第一笔 | First Edit | 1 | 10 |
| uncommon | `file-edits-10` | 🩹 | 小修小补 | Patchwork | 10 | 30 |
| rare | `file-edits-50` | 🔨 | 改造能手 | Code Tinkerer | 50 | 75 |
| epic | `file-edits-250` | 🏗️ | 重构老手 | Refactor Veteran | 250 | 175 |
| legendary | `file-edits-1000` | ⚒️ | 千锤百炼 | Thousand Edits | 1000 | 400 |

指标：`profile.fileEdits`，统计成功 edit/write invocation 次数。

### G. 测试之路 / Test Runs

| Rarity | ID | 图标 | 中文标题 | English | Target | XP |
|---|---|---|---|---|---:|---:|
| common | `tests-1` | 🧪 | 试运行 | First Test | 1 | 10 |
| uncommon | `tests-10` | ✅ | 测试习惯 | Test Habit | 10 | 30 |
| rare | `tests-50` | 🚦 | 测试巡航 | Test Cruiser | 50 | 75 |
| epic | `tests-250` | ⚗️ | 测试炼金术 | Test Alchemist | 250 | 175 |
| legendary | `tests-1000` | 🧬 | 千测不怠 | Test Marathon | 1000 | 400 |

指标：`profile.testRuns`，pass/fail 都算一次运行。

## 3. 新增数量核算

| 系列 | 新增数 |
|---|---:|
| Turns | 3 |
| Tools | 3 |
| Sessions | 4 |
| Active Days | 5 |
| File Reads | 5 |
| File Edits | 5 |
| Tests | 5 |
| **合计** | **30** |

当前 18 + 新增 30 = **48**。

## 4. Achievement Chains

`src/share.ts` 当前：

```ts
BUILTIN_CHAINS = [turns, tools, streaks, behavior]
```

P6 推荐拆出两个语义集合：

```ts
export const MILESTONE_CHAINS: readonly AchievementChain[] = [
  turns,
  tools,
  sessions,
  activeDays,
  fileReads,
  fileEdits,
  tests,
]

export const SPECIAL_CHAINS: readonly AchievementChain[] = [
  streaks,
  behavior,
]

export const BUILTIN_CHAINS = [...MILESTONE_CHAINS, ...SPECIAL_CHAINS]
```

命名可微调，但必须允许 Badge Wall 明确知道哪 7 条是正式五级成长线，而不需要硬编码 35 个 id。

### 正式 chain ids

建议：

```text
turns
tools
sessions
active-days
file-reads
file-edits
tests
```

### `achievementIds` 顺序

严格按 rarity/threshold 顺序填写，不按定义数组中的出现顺序自动猜测。

例如：

```ts
{
  id: 'turns',
  achievementIds: [
    'first-turn',
    'turns-25',
    'turns-50',
    'hundred-turns',
    'turns-500',
  ],
}
```

## 5. Built-in 定义组织建议

避免把 48 个对象完全平铺成难维护的单数组。

可组织为：

```ts
export const COUNTER_ACHIEVEMENTS = [...] // legacy-compatible names if retained
export const MILESTONE_ACHIEVEMENTS = [...]
export const BEHAVIOR_ACHIEVEMENTS = [...]

export const BUILTIN_ACHIEVEMENTS = [
  ...MILESTONE/legacy lifetime definitions,
  ...BEHAVIOR_ACHIEVEMENTS,
]
```

但必须注意不要重复包含 `first-turn` 等旧成就。

更推荐最终做到“每个 built-in definition 在 `BUILTIN_ACHIEVEMENTS` 中只出现一次”，由 chain 只引用 ID。

## 6. Pack Version

`BUILTIN_PACK.version` 当前为 `0.2.0`。

P6 内容发生显著新增，应更新 built-in pack metadata version。具体版本遵从项目发布策略；如果没有其它版本约束，建议：

```text
0.6.0
```

注意 package `version` 是否同步升级属于发布决定，不要在没有明确要求时顺便修改 npm package version。

## 7. 必须自动化验证的目录不变量

新增测试必须直接从 Definitions + Chains 验证，而不是手工重复写期望表。

对每个 `MILESTONE_CHAINS`：

```text
achievementIds.length === 5
每个 id 都能在 BUILTIN_ACHIEVEMENTS 找到
无重复 id
scope === lifetime
rarity sequence === [common, uncommon, rare, epic, legendary]
target 严格递增
```

由于 target 存在 `evaluate()` 返回值中，可使用构造不同 profile 值的方式验证，或在 Milestone helper 上保留内部可测试 spec。不要为了测试给 Browser View 暴露不必要的 engine metadata。

## 8. Legacy 回归

以下旧数据必须保持：

```text
first-turn          common / 10 XP / 1 turn
ten-turns           common / 20 XP / 10 turns
hundred-turns       epic / 200 XP / 100 turns
first-tool          common / 10 XP / 1 tool
hundred-tools       rare / 150 XP / 100 tools
ten-sessions        uncommon / 50 XP / 10 sessions
streak-3            uncommon / 50 XP / 3-day streak
streak-7            legendary / 500 XP / 7-day streak
```

现有 10 个 Session 行为成就也不得改 threshold/rarity/XP。

## 禁止事项

- 不为了五档整齐而修改 `ten-turns` 的 rarity。
- 不把 streak 强行扩成 1/3/5/6/7 这种伪五档。
- 不从 Session buckets 求 lifetime 文件/测试 progress。
- 不让新 Milestone 使用 `scope: 'session'`。
- 不修改行为成就条件。
- 不手改 `lib/`。

## Definition of Done

- [ ] 新增准确 30 个 built-in milestones
- [ ] Built-in 总数为 48
- [ ] 7 条正式 chain 各 5 个节点
- [ ] 五档 rarity 顺序全部正确
- [ ] 所有新成就有 progress/target
- [ ] 旧 18 个成就元数据与触发语义不变
- [ ] chain regression tests 通过
