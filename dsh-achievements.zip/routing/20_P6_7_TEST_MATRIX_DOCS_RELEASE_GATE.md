# Task 20 — P6.7 Full Test Matrix / Docs / Release Gate

| 字段 | 内容 |
|---|---|
| 优先级 | **P6.7 / 发布阻塞** |
| 前置依赖 | Task 13–19 |
| 核心目标 | 为 P6 的事件覆盖、状态演进、30 个新成就、历史补发和 UI 元数据建立完整回归保护，并更新用户/Agent 文档 |
| 风险 | 低（但覆盖面广） |
| 最终 Gate | `npm run verify` |

## 1. 测试层次

P6 必须继续遵守现有三层测试定位：

```text
Raw Harness payload
→ classifier / adapter tests
→ reducer tests
→ achievement evaluate / engine tests
```

不要只写端到端测试，让失败原因无法定位。

## 2. Event Coverage Matrix

### Native tools

继续验证：

- read
- write/edit
- shell
- test runner
- unknown tool
- malformed arguments
- success/error

### Code Mode

新增：

- code-dispatch read
- code-dispatch edit
- code-dispatch shell
- code-dispatch test pass
- code-dispatch test fail
- unknown child tool
- one settled child invocation counted exactly once

Native 与 Code Mode 的等价子调用应产生等价 `ToolSummary` / reducer facts。

## 3. Reducer Matrix

### Lifetime counters

| Metric | Negative | Positive | Edge |
|---|---|---|---|
| activeDays | 同日第二个 turn 不 +1 | 新自然日 +1 | streak 中断但 activeDays 仍 +1 |
| fileReads | failed read +0 | successful read +1 | 同文件多次逐次 +1 |
| fileEdits | failed edit +0 | successful edit +1 | write/edit 都归入 file-edit |
| testRuns | non-test shell +0 | test pass/fail 都 +1 | pass/fail 分流正确 |
| testPasses | failed test +0 | passed test +1 | 多次累积 |
| testFailures | passed test +0 | failed test +1 | 多次累积 |

同时回归：

- `turns`
- `toolCalls`
- `toolsByName`
- `sessions`
- `currentStreak`
- `longestStreak`
- Session behavior fields

## 4. State / Migration Matrix

必须覆盖：

1. fresh v2 state 新字段全为 0；
2. old v2 missing P6 fields；
3. new v2 persisted P6 fields；
4. persisted 0 不被当 missing；
5. retained sessions lower-bound backfill；
6. v1 → v2 migration；
7. corrupt/unknown state fallback；
8. `MAX_SESSIONS` 裁剪仍正确；
9. normalize twice 幂等。

## 5. Milestone Threshold Matrix

对每一条正式 chain，至少参数化验证全部 5 个 target：

```text
N - 1 → locked
N     → unlocked
N + 1 → remains eligible
```

不建议为 35 个节点复制 105 段手写测试。使用 table-driven tests。

示例结构：

```ts
const cases = [
  ['first-turn', 'turns', 1],
  ['turns-25', 'turns', 25],
  ...
]
```

根据 metric key 构造 Profile。

## 6. Chain Structural Invariants

对 `MILESTONE_CHAINS` 自动验证：

```text
chain count === 7
每条 length === 5
所有 id 存在
所有 id 全局不重复（正式 chain 内至少不重复）
scope 全 lifetime
rarity sequence 固定
threshold strictly increasing
```

如果 threshold 只存在 evaluate closure 中，测试可通过边界探测得到；不要为了测试把不必要的内部数据发送到 Browser API。

## 7. Catalog Count Invariants

基准：

```text
legacy/current = 18
new P6 = 30
built-in total = 48
```

测试建议至少断言：

```ts
expect(BUILTIN_ACHIEVEMENTS).toHaveLength(48)
```

同时：

```text
all built-in ids unique
```

避免 registry 到运行时才发现重复 id。

## 8. Legacy 18 Regression

建立一个明确的 legacy metadata fixture，至少锁定：

```text
id
rarity
xp
scope
threshold behavior
```

特别关注 8 个旧 Lifetime：

```text
first-turn
ten-turns
hundred-turns
first-tool
hundred-tools
ten-sessions
streak-3
streak-7
```

以及现有 10 个 behavior 的 positive/negative case。

P6 不允许“为了统一”悄悄改变这些值。

## 9. XP / Unlock Idempotency

### Live applyEvent

同 achievement：

```text
第一次达到 threshold → +XP + unlock
后续事件 → 不重复 +XP
```

### Silent reconcile

```text
第一次 startup reconcile → 补 unlock + XP
第二次 → 0 新解锁 / 0 XP
```

### Reconcile 与 Live 交叉

如果 startup 已经 reconcile：

```text
下一次 live event 不应再次解锁/发 XP
```

## 10. Session Attribution

必须证明：

### Live unlock

仍然写入：

```text
session.unlocked
session.xpGained
```

### Historical reconcile

绝不写入：

```text
session.unlocked
session.xpGained
```

这样最近会话战报不会显示历史 milestone。

## 11. Progress API

验证：

- 新 35 个正式 milestone 都有 progress/target；
- progress 可超过 target；
- current recent session 仍用于 Session achievement progress；
- Lifetime achievement progress 与最近 session id 无关；
- `/state` snapshot 序列化不包含 evaluate function。

## 12. UI / Browser-safe Regression

至少验证纯 helper/metadata：

- `MILESTONE_CHAINS` 7 条；
- `chainProgressOf()` 0/5、部分、5/5；
- rarity summary 总数随 48 defs 正确；
- hidden achievement view 仍 masked（如已有相关测试）；
- share 仍不包含 paths/commands。

最终必须执行 `npm run build`，因为 TypeScript test 不能代替 client purity gate。

## 13. 文档更新

### 必须更新

`AGENTS.md`

- 当前成就总数；
- 7 条五级 Lifetime progression；
- 新 Profile lifetime counters；
- Code Mode 已接入（完成后再把“已知坑”移除/改写）；
- P6 routing 12–20 已实现状态。

`README.zh.md` / `README.md`

至少说明：

- 5 个 rarity；
- 7 条核心成长路线；
- 长期累计与 Session 行为双轨；
- 老状态会尽可能恢复近期可证明的 lifetime 数据；
- 分享隐私边界不变。

`routing/README_STAGE_PLAN.md`

把 P6 从规划标记为完成时，需要更新阶段状态。

### 可选更新

`docs/SDK.md`

如果 Task 18 对 `ctx.achievements.register/registerPack` 的“注册后立即 silent lifetime reconcile”改变了可观察行为，应在 SDK 文档明确：

> 新注册的 lifetime definition 可能根据当前 profile 立即被静默解锁；session definition 只在后续 live event 中正常评估。

## 14. Release Command Gate

按顺序执行：

```bash
npm run typecheck
npm test
npm run build
npm run verify
```

如果 `build` 因项目已知 optional peer / Node engine 环境问题失败，必须区分：

- P6 代码错误；
- 本机环境缺少 `unrun` / `synckit`；
- Node < package 要求。

不要把真实代码错误归因于已知环境问题。

## 15. 发布前人工 Smoke Test

建议实际安装 tarball 后验证：

1. 打开旧 state，插件启动无错误；
2. 历史 Lifetime milestone 已补解锁，但没有连续 Toast；
3. 新做一次 read/edit/test，实时 counters 增加；
4. 达到一个新 threshold 时只弹 1 次 Toast；
5. Badge Wall 显示 7 条 `/5` 成长路线；
6. 重启 DSH 后不重复补 XP；
7. 分享文本无路径与命令。

仍使用项目已知可靠安装方式：

```text
npm pack + tarball install
```

不要回退到已知有 Windows junction 问题的 `link:` 安装。

## Definition of Done

- [ ] classifier / reducer / evaluate / reconciliation 分层测试齐全
- [ ] 35 个正式 milestones 有 table-driven threshold coverage
- [ ] 7 条 chain structural invariants 有测试
- [ ] Built-in 总数和 ID uniqueness 有测试
- [ ] 原 18 个成就有回归保护
- [ ] silent reconciliation 幂等且不污染 session
- [ ] state migration/backfill 幂等
- [ ] README / AGENTS / routing 文档更新
- [ ] `npm run typecheck` 通过
- [ ] `npm test` 通过
- [ ] `npm run build` 通过
- [ ] `npm run verify` 通过
