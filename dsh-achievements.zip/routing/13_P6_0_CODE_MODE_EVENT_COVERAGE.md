# Task 13 — P6.0 Code Mode Event Coverage

| 字段 | 内容 |
|---|---|
| 优先级 | **P6.0 / 统计正确性阻塞** |
| 前置依赖 | Task 00–12 |
| 核心目标 | 让 Code Mode 内部 `tool/code-dispatch` 子调用复用现有 classifier，并进入统一 `AchievementEvent` → reducer → evaluate 路径 |
| 风险 | 中（依赖 DSH 原始事件 schema） |
| 完成后解锁 | 文件读取/修改/测试等 Lifetime Milestone 的可信统计 |

## 当前基线

Host 当前在 `src/index.ts` 只处理：

```text
turn/end
tool/call
tool/result
```

普通工具路径：

```text
tool/call
  → classifyTool(name, args)
  → pendingCalls[callId]

tool/result
  → buildToolCallEvent(...)
  → applyEvent(...)
```

项目已知问题：Code Mode 中 `run_code` 的内部子调用通过 `tool/code-dispatch` 记录，因此这些内部 read/edit/shell/test 行为当前不会进入 Achievement reducer。

## 关键原则

### 1. 不在规则层识别 Code Mode

不要给 `AchievementDef.evaluate()` 增加任何 `run_code` / `code-dispatch` 特判。

正确层级仍然是：

```text
Harness raw event
→ adapter / classifier
→ AchievementEvent(kind='tool-call')
→ reduceState
→ evaluate
```

### 2. 必须复用 `classifyTool()`

`tool/code-dispatch` 中只要能得到子工具的：

- tool name
- arguments
- settled result / error

就应该转成现有 `ToolSummary`，而不是再维护第二套 read/edit/test 分类规则。

### 3. 不猜测 DSH payload

在开始编码前，Agent 必须先读取当前安装版本的 DSH event type / source，确认 `tool/code-dispatch` 的真实 payload 结构。

不得根据名字自行假设：

- 字段名；
- call id 所在位置；
- arguments 是否是 JSON string；
- error 的判定字段；
- 一个事件代表开始、结束还是完整 settled invocation。

如果当前 DSH 类型定义不足以确认，请从本地运行时包中继续查找实际事件生产代码，并把确认结果写入测试 fixture 注释。

## 目标语义

P6.0 完成后，每个**已经 settled 的 Code Mode 子工具调用**应最终产生一个标准：

```ts
{
  kind: 'tool-call',
  sessionId,
  seq,
  callId,
  tool: classifyTool(name, args),
  isError,
}
```

随后完全复用现有：

```ts
applyAchievementEvent(...)
```

## 执行任务表

| # | 任务 | 输出 | 验收标准 |
|---|---|---|---|
| 1 | 查明 `tool/code-dispatch` schema | 代码注释/fixture | 不依赖猜测 |
| 2 | 抽出 raw-event → settled ToolSummary 的最小 adapter | pure helper 优先 | 普通路径与 Code Mode 路径可共享分类逻辑 |
| 3 | 在 `session/event` handler 增加 Code Mode 分支 | Host wiring | 子调用能进入 `applyAchievementEvent` |
| 4 | 明确 error/pass 语义 | adapter | test-run 成败与原生工具一致 |
| 5 | 明确 callId 语义 | adapter | 有稳定 id 时透传；没有时允许 `null`，不要伪造冲突 id |
| 6 | 防止单个 code-dispatch 子调用被重复计数 | 测试 | 同一 settled 子调用只 +1 |
| 7 | 保持普通 `tool/call` + `tool/result` 行为不变 | 回归测试 | 现有 classifier/reducer 测试继续通过 |

## 建议实现边界

优先修改：

```text
src/events.ts
src/index.ts
tests/classifier.spec.ts
```

如需要 Host event fixture，可新增专门测试文件；不要把 DSH raw payload 解析塞进 `reducer.ts`。

## 关于 `run_code` 顶层调用

本任务的目标是**补齐内部子调用缺失**，不是重新定义现有 `toolCalls` 历史语义。

如果顶层 `run_code` 本身仍经普通 `tool/call` + `tool/result` 被计数，则默认保持现状。不要在 P6.0 顺便改变既有工具调用计数口径，除非通过真实事件序列证明会产生明确的重复 settled invocation，并在任务实现说明中记录该兼容性决定。

## 必须覆盖的测试

### Classifier / Adapter

- `code-dispatch` read → `file-read`
- `code-dispatch` edit/write → `file-edit`
- `code-dispatch` shell → `shell-command`
- `code-dispatch` test command → `test-run`
- unknown child tool → `other`
- malformed args → 安全 fallback
- failed child call → `isError: true`
- successful child call → `isError: false`

### Integration-shaped pure test

至少构造：

```text
Code Mode read
→ Code Mode edit
→ Code Mode npm test (pass)
```

并验证 reducer 结果与等价原生工具事件一致：

```text
session.toolCalls
session.filesRead
session.filesEdited
session.tests
profile.toolCalls
profile.toolsByName
```

## 禁止事项

- 不复制一套 `isTestCommand()`。
- 不让 reducer 读取 DSH event type。
- 不把 `tool/code-dispatch` 直接变成新的 AchievementEvent kind，除非有无法映射到 settled `tool-call` 的硬证据。
- 不在本任务调整成就 threshold / XP。
- 不手改 `lib/`。

## Definition of Done

- [ ] 已基于真实 DSH schema 实现 Code Mode adapter
- [ ] Code Mode read/edit/test 可进入现有 `AchievementEvent` 流
- [ ] 普通工具路径不回归
- [ ] 子调用不会重复计数
- [ ] `npm run typecheck` 通过
- [ ] `npm test` 通过
