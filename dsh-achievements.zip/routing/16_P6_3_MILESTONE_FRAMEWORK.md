# Task 16 — P6.3 Lifetime Milestone Framework

| 字段 | 内容 |
|---|---|
| 优先级 | **P6.3 / 规则可维护性** |
| 前置依赖 | Task 14–15 |
| 核心目标 | 在不破坏 `fromCounterCondition()` SDK 兼容的前提下，为大量 Lifetime threshold 成就提供统一、可测试的 Milestone 定义方式 |
| 风险 | 低中 |
| 主要文件 | `src/achievements.ts`, achievement tests |

## 当前问题

现有旧 Lifetime 成就主要使用：

```ts
fromCounterCondition(...)
```

它最终只返回：

```ts
{ unlocked: boolean }
```

因此 `computeProgress()` 无法为这些累计成就提供：

```text
progress / target
```

P6 将新增 30 个 Milestone。如果逐个手写 `evaluate()`，会出现大量重复：

```ts
evaluate: ctx => ({
  unlocked: ctx.profile.fileReads >= 500,
  progress: ctx.profile.fileReads,
  target: 500,
})
```

## 设计目标

新增一个内部通用 helper，概念形态：

```ts
createLifetimeMilestone({
  id,
  icon,
  title,
  description,
  flavorText?,
  rarity,
  xp,
  target,
  value: profile => profile.fileReads,
})
```

生成：

```ts
{
  ...metadata,
  scope: 'lifetime',
  evaluate: ctx => {
    const progress = value(ctx.profile)
    return {
      unlocked: progress >= target,
      progress,
      target,
    }
  },
}
```

helper 命名可调整，但语义必须保持上述一致性。

## Helper 类型建议

```ts
interface LifetimeMilestoneSpec {
  id: string
  icon: string
  title: LocalizedText
  description: LocalizedText
  flavorText?: LocalizedText
  rarity: AchievementRarity
  xp: number
  target: number
  value(profile: ProfileState): number
}
```

可根据 TypeScript 推导适当简化。

## 是否公开 helper

默认：**内部 helper，不新增 Public SDK surface。**

理由：

- P6 主要解决 built-in 目录维护；
- 当前 SDK 已允许第三方直接写 `evaluate(ctx)`；
- 过早公开 helper 会形成需要长期兼容的 API。

除非实现过程中有明确 API 评审，不要把它加入 `src/index.ts` 的 public export。

## 保留 `fromCounterCondition()`

现有 public compatibility helper：

```ts
fromCounterCondition(...)
```

必须保留其签名和行为，以免破坏第三方代码。

可以新增内部 helper，而不是重定义旧函数。

## 旧 Built-in Lifetime 成就的 Progress 改造

P6 允许让已有累计成就开始返回 progress/target，但必须保持：

```text
id 不变
threshold 不变
rarity 不变
xp 不变
scope 不变
```

建议将以下旧累计成就切换到 milestone helper（或等价 threshold helper）：

- `first-turn` target 1
- `ten-turns` target 10
- `hundred-turns` target 100
- `first-tool` target 1
- `hundred-tools` target 100
- `ten-sessions` target 10
- `streak-3` target 3（可继续使用 currentStreak）
- `streak-7` target 7

这样 Badge Wall 能显示旧 Lifetime 成就的标准进度条。

如果为了保持 streak 与 milestone 的概念分离，也可以为 streak 使用另一个轻量 threshold helper；核心要求是 progress/target 数据准确。

## Progress 语义

### 不 clamp 原始 progress

如果目标是 100，实际值 250：

```ts
progress: 250
target: 100
```

UI 自己通过 `Math.min(100, ...)` 控制进度条宽度。

不要把 progress 强制截断成 target，否则其它 ViewModel 失去真实值。

### target 必须 > 0

所有 Milestone target 必须是正整数。

建议 helper 在开发期至少通过类型/测试保证；是否 runtime throw 可根据现有风格选择，但不要允许 target=0 的 built-in 定义进入目录。

## 新 Milestone XP 基准

helper 不应该自动根据 rarity 决定 XP，以免改变旧成就和未来特殊成就的灵活性。

目录层显式传入：

```text
common       10
uncommon     30
rare         75
epic        175
legendary   400
```

## 执行任务表

| # | 任务 | 输出 | 验收标准 |
|---|---|---|---|
| 1 | 增加 Lifetime Milestone helper | pure factory | threshold 规则统一 |
| 2 | helper 返回 progress/target | evaluate | `computeProgress` 可直接消费 |
| 3 | 保留 `fromCounterCondition` | compatibility | public API 不破坏 |
| 4 | 将旧 lifetime counter defs 改为有 progress | refactor | 元数据/threshold 不变 |
| 5 | 加 helper 单测 | tests | N-1/N/N+1 行为正确 |
| 6 | 验证已解锁仍由 `applyEvent` 的 `unlocked` guard 保证一次性 XP | regression | 不重复 XP |

## 必须测试

对任意 target=50 的 milestone：

```text
progress 49 → unlocked false, progress 49, target 50
progress 50 → unlocked true,  progress 50, target 50
progress 51 → unlocked true,  progress 51, target 50
```

对旧 `hundred-tools`：

```text
99 → locked + progress 99/100
100 → unlock
rarity 仍 rare
xp 仍 150
```

对旧 `hundred-turns`：

```text
rarity 仍 epic
xp 仍 200
```

## 禁止事项

- 不删除 `fromCounterCondition()`。
- 不自动重定价旧 Achievement。
- 不把 rarity → XP 写死在 engine。
- 不让 helper 读取 SessionState。
- 不在 helper 中直接写 state/unlocked/XP；它只产生 Definition/evaluation。
- 不手改 `lib/`。

## Definition of Done

- [ ] 新 Lifetime Milestone 可用单一 helper 定义
- [ ] progress/target 标准化
- [ ] 旧累计成就可显示进度且语义不变
- [ ] public SDK compatibility 不变
- [ ] `npm run typecheck` / `npm test` 通过
