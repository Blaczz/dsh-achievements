# Task 19 — P6.6 Badge Wall Information Architecture

| 字段 | 内容 |
|---|---|
| 优先级 | **P6.6 / UX 必需** |
| 前置依赖 | Task 17–18 |
| 核心目标 | 在 Built-in Achievement 从 18 增长到约 48 后，保持设置页可扫描、可理解、可看到七条成长路线 |
| 风险 | 中（Client bundle / UI 密度） |
| 主要文件 | `src/client/badge-panel.tsx`, `src/share.ts` 或 browser-safe helper, UI-related tests |

## 当前问题

Badge Wall 当前直接：

```tsx
defs.map(def => <AchievementCard ... />)
```

18 个时尚可接受，48 个后会形成很长的平铺列表，用户难以理解：

- 自己正在推进哪条路线；
- 为什么同类成就有多个 rarity；
- 哪些是长期里程碑；
- 哪些是 Session 行为彩蛋。

同时 lifetime stats 目前只显示：

```text
回合 / 工具调用 / 会话 / 当前连续天数
```

P6 新增长期指标也需要可见。

## 产品结构

设置页成就区域建议变成：

```text
🏆 成就 23/48

[成长里程碑]
  回合之路       3/5
  工具之途       2/5
  会话旅程       1/5
  活跃岁月       2/5
  阅读之路       3/5
  编辑之路       2/5
  测试之路       2/5

  ... Milestone achievement cards ...

[特殊行为]
  ten-turns
  streak-3 / streak-7
  Déjà Vu
  Rabbit Hole
  YOLO
  One Shot
  Gigachad
  ...
```

不要求本阶段做复杂动画、搜索、分页或虚拟列表。

## 1. Milestone 与 Special 的分类来源

不要在 JSX 中手写 35 个 milestone ID。

优先复用 Task 17 的：

```ts
MILESTONE_CHAINS
```

构建：

```ts
const milestoneIds = new Set(
  MILESTONE_CHAINS.flatMap(chain => chain.achievementIds)
)
```

然后：

```text
milestone defs = id in milestoneIds
special defs = other defs
```

这能保证 UI 与 chain catalog 同源。

第三方 pack defs 若不在 built-in milestone chains 中，默认进入“其它/特殊成就”区域即可；不要为了 P6 引入新的 SDK category 字段。

## 2. Lifetime Stats 重构

当前 `STAT_ROWS` 四列固定 flex。P6 后建议改为 responsive grid。

至少展示：

```text
turns          回合
toolCalls      工具调用
sessions       会话
activeDays     活跃天数
fileReads      读文件
fileEdits      改文件
testRuns       测试
```

streak 建议独立展示：

```text
当前连续 N 天 · 最长连续 M 天
```

而不是挤进七个主成长指标。

### 不要混淆 Session distinct files

Profile stats 中：

```text
fileReads / fileEdits
```

是 Lifetime invocation counts。

最近会话战报中的：

```text
filesRead / filesEdited
```

当前 `buildSessionSummary()` 是 distinct file count。

UI 标签需保持语义可理解，不能让用户误以为两个数字是同一口径。

建议：

- Lifetime：`读取次数` / `修改次数`
- Session report：`读文件` / `改文件`（或进一步标记“不同文件”）

## 3. Chain 区域

Task 17 新增 7 条 `MILESTONE_CHAINS` 后，现有“🔗 成就链”可以升级为主成长路线概览。

每条继续显示：

```text
Title    progress bar    completed/5
```

可选增强：显示下一档名称/rarity，但不是 P6 必需。

必须确保 7 条主链不会与 `streaks` / `behavior` 混在一起导致难以辨认。

建议分组：

```text
📈 成长路线
  7 milestone chains

🎭 特殊链
  连续作战
  行为狂人
```

## 4. Achievement Cards

继续复用现有 Card 视觉与：

- rarity border/background；
- hidden mask；
- progress bar；
- +XP；
- elapsed unlock time。

本任务不要重做整套视觉系统。

### 排序

成长里程碑应优先按：

```text
chain order
→ common → uncommon → rare → epic → legendary
```

而不是单纯按 `BUILTIN_ACHIEVEMENTS` 注册顺序依赖隐式布局。

Special 可以保留现有定义顺序。

### 已解锁/未解锁排序

默认不要把所有已解锁强行移到最前，否则会破坏五级路线的视觉连续性。

五级 Milestone 应保持固定 progression 顺序。

## 5. Rarity 汇总

现有 Profile 已显示：

```text
普通 x/y
罕见 x/y
稀有 x/y
史诗 x/y
传说 x/y
```

继续保留。

P6 大量新增后，这个区域会更有意义，不需要另外引入 rarity filter 才能发布。

如果实现 Agent 时间充足，可增加轻量 filter，但不作为 Definition of Done，避免 UI 状态复杂度扩大。

## 6. Browser Safety

Client 不能运行时 import：

```text
state.ts
achievements.ts（Host-only dependency chain）
```

现有 `badge-panel.tsx` 对 `AchievementRarity` 只 `import type`，这个边界继续保持。

用于 UI 分类的 chain metadata 应放在 browser-safe 模块，例如当前 `share.ts`，或新增无 Node dependency 的纯 metadata/helper 模块。

最终必须跑：

```bash
npm run build
```

由 `tsdown.config.ts` 的 purity gate 验证。

## 7. 分享隐私边界

本任务不需要把 fileReads/fileEdits/testRuns 加入分享文本。

如果决定在 Agent Wrapped UI 中显示 aggregate counters，必须仍只使用数字，不读取：

- `filesRead` path map；
- `filesEdited` path map；
- `commands`。

`buildShareText()` / `buildAgentWrapped()` 的隐私不变量不能因 UI 扩展而破坏。

## 执行任务表

| # | 任务 | 输出 | 验收标准 |
|---|---|---|---|
| 1 | 从 milestone chains 派生 UI 分组 | helper/UI | 不硬编码 35 ids |
| 2 | Achievement grid 分“成长里程碑/特殊行为” | UI | 48 个卡片可扫描 |
| 3 | 7 个 Lifetime 主指标 responsive 展示 | UI | 小宽度不溢出 |
| 4 | streak 独立显示 | UI | activeDays 与 streak 不混淆 |
| 5 | 成长路线/特殊链分组 | UI | 7 条正式 chain 清晰 |
| 6 | 保持 hidden/progress/rarity/XP Card 行为 | regression | 现有功能不丢失 |
| 7 | build purity gate | build | Client 无 Host-only import |

## 必须验证

- 48 个 definitions 的 snapshot 能正常渲染；
- 所有 7 条成长链能显示 `0/5` 到 `5/5`；
- locked milestone progress 有数值与进度条；
- hidden achievement 未解锁时仍不泄露；
- 小屏/窄设置面板下统计卡不会固定四列挤爆；
- old snapshot 中新 profile 字段经 state normalize 后存在，不需要 Client 额外 fallback；
- share text 仍不包含路径/命令。

## 禁止事项

- 不在 JSX 手写 35 个 milestone id。
- 不为分类把 `AchievementDef` SDK 强制扩展为必填 category。
- 不运行时 import Host-only `state.ts` / `achievements.ts`。
- 不为了展示统计读取 Session path/command 细节。
- 不在本任务做排行榜/社交 UI。
- 不手改 `lib/`。

## Definition of Done

- [ ] 48 个成就下页面仍可快速理解
- [ ] 里程碑与特殊行为清楚分组
- [ ] 7 条成长路线可见且均显示 `/5`
- [ ] 新 Lifetime stats 可见
- [ ] activeDays 与 streak 语义不混淆
- [ ] `npm run build` purity gate 通过
