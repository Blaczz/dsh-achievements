# Task 18 — P6.5 Silent Lifetime Reconciliation

| 字段 | 内容 |
|---|---|
| 优先级 | **P6.5 / 老用户体验** |
| 前置依赖 | Task 17 |
| 核心目标 | 升级后根据已有 Profile 静默补齐已经满足的 Lifetime Achievement，并一次性补发 XP，避免下一次事件触发 Toast storm |
| 风险 | 中高（XP 幂等、session attribution、SDK registration timing） |
| 主要文件 | `src/achievements.ts`, `src/index.ts`, tests |

## 问题场景

用户升级 P6 前已有：

```text
turns = 500
toolCalls = 1000
sessions = 80
```

P6 新增：

```text
turns-25
turns-50
turns-500
tools-25
tools-500
sessions-1
sessions-50
...
```

如果不做启动 reconciliation，那么用户下一次任意事件调用 `applyEvent()` 时，会一次性：

- 解锁多个历史已满足的 achievement；
- 把它们全部记入当前 session；
- 通过 SSE 连续发多个 Toast；
- Session report 错误显示“本会话解锁”大量历史里程碑。

## 目标行为

P6 启动后，应先执行一次**静默 Lifetime reconciliation**：

```text
loadState
→ register BUILTIN_PACK
→ reconcile all locked lifetime defs against current profile
→ award XP once
→ persist
→ start normal live event handling
```

### Reconciliation 必须做

- 检查 `scope === 'lifetime'`；
- 只处理 `id not in profile.unlocked`；
- `evaluate(ctx).unlocked === true` 时写入 unlock timestamp；
- 累加 def.xp；
- 返回/记录哪些定义被补齐，便于日志/测试。

### Reconciliation 必须不做

- 不创建/修改 `session.unlocked`；
- 不增加 `session.xpGained`；
- 不调用 `broadcastUnlock()`；
- 不触发 Toast；
- 不执行 reducer；
- 不修改 turns/toolCalls 等行为 counters；
- 不追溯 `scope === 'session'` 的成就。

## Pure Engine Helper

建议在 `src/achievements.ts` 增加纯函数：

```ts
reconcileLifetimeAchievements(
  state: AchievementState,
  defs: readonly AchievementDef[],
  now = Date.now(),
): AchievementProgress
```

或等价返回结构。

核心伪代码：

```ts
const unlocked = { ...state.profile.unlocked }
const newlyUnlocked: AchievementDef[] = []
let xpGained = 0
const ctx = buildContext(state, '')

for (const def of defs) {
  if (def.scope !== 'lifetime') continue
  if (def.id in unlocked) continue
  if (!def.evaluate(ctx).unlocked) continue

  unlocked[def.id] = now
  newlyUnlocked.push(def)
  xpGained += def.xp
}

return {
  state: {
    ...state,
    profile: {
      ...state.profile,
      unlocked,
      xp: state.profile.xp + xpGained,
    },
  },
  newlyUnlocked,
}
```

实现可复用现有内部逻辑，但不要让 live `applyEvent()` 的 session attribution 被 reconciliation 复用错。

## Timestamp 语义

历史真实完成时间不可知。

因此：

```text
profile.unlocked[id] = reconciliation 执行时刻
```

这是“系统确认解锁时间”，不是伪造历史完成日期。

不要尝试根据 `lastActiveDay`、session seq 或文件路径推断具体历史时间。

## XP 语义

如果过去已经满足一个**P6 新成就**，升级时应该获得该新成就 XP。

幂等来源仍然是：

```ts
if (!(def.id in unlocked))
```

第二次启动：

```text
0 newly unlocked
0 XP added
```

## Host Wiring

### Built-in Pack

推荐顺序：

```ts
let state = loadState()
const registry = createAchievementRegistry()
registry.registerPack(BUILTIN_PACK)

const backfill = reconcileLifetimeAchievements(state, registry.list())
state = backfill.state
persist if changed
```

注意当前 `persist()` helper 定义位置可能需要小幅调整；保持逻辑清晰即可。

### 第三方 SDK 注册

当前：

```ts
ctx.provide('achievements', {
  register: registry.register,
  registerPack: registry.registerPack,
})
```

P6 推荐 Host 层包装这两个方法：

```text
register definition
→ registry add
→ 对刚注册的 lifetime def 做 silent reconcile
→ persist if changed
```

`registerPack` 同理，可以注册完成后对该 Pack 的 defs 一次 reconcile。

这样第三方新增 Lifetime Achievement 也不会必须等到“下一次用户事件”才解锁。

保持：

- `createAchievementRegistry()` 本身仍是纯 registry；
- duplicate id 行为仍由 registry 抛异常；
- session-scope third-party def 不追溯。

如果实现复杂度过高，最低要求是 Built-in P6 成就完成 startup reconcile；但应在文档中明确第三方 pack 的后续行为。优先实现通用 Host wrapper。

## 日志

可以打印一条聚合日志，例如：

```text
[achievements] reconciled 8 lifetime achievements (+1120 XP)
```

不要逐个调用现有 `handleUnlocks()`，因为它包含 SSE broadcast。

## 执行任务表

| # | 任务 | 输出 | 验收标准 |
|---|---|---|---|
| 1 | 新增 pure lifetime reconcile helper | engine | 不 reducer、不 session attribution |
| 2 | 启动时在 live handler 前运行 | Host | 老用户历史 milestone 先补齐 |
| 3 | persistence 仅在 state 改变时执行 | Host | 不必要写盘可避免 |
| 4 | 不调用 unlock SSE | Host | 无 Toast storm |
| 5 | SDK register/registerPack 包装 reconcile | Host | 新 lifetime pack 立即静默评估 |
| 6 | 幂等测试 | tests | 第二次 reconcile 0 XP |

## 必须测试

### Positive Backfill

state：

```text
turns = 500
unlocked = {}
xp = 0
```

defs：回合五级 chain。

reconcile 后：

```text
5 个正式回合 milestone 全部解锁
XP = 各节点 XP 总和
sessions 保持完全不变
```

注意若 `ten-turns` 也在 defs 且为 lifetime，它也会满足；测试应明确是对“全部 lifetime defs reconcile”还是只传正式 chain defs，不要写模糊断言。

### Locked Remains Locked

```text
turns = 24
turns-25 不解锁
```

### Session Scope Ignored

即使某个 Session 行为当前 ctx 恰好满足：

```text
scope === session
```

也不得在 reconciliation 中补解锁。

### Idempotency

第一次：

```text
+N XP
```

第二次同样 state/defs：

```text
+0 XP
unlocked timestamp 不改变
```

### No Session Attribution

reconcile 前后：

```ts
state.sessions
```

deepEqual。

## 禁止事项

- 不通过模拟一个假的 `turn-end` 来触发历史成就。
- 不调用 `applyEvent()` 完成 startup backfill。
- 不把 backfill achievement 写入最近 session。
- 不广播 SSE。
- 不追溯 Session 成就。
- 不修改历史 counters 来“凑”成就。
- 不手改 `lib/`。

## Definition of Done

- [ ] 老用户启动后自动补齐已满足 Lifetime 成就
- [ ] XP 只补一次
- [ ] session report 不被历史补发污染
- [ ] 不产生 Toast storm / SSE unlock storm
- [ ] 第三方 lifetime registration 行为有明确实现或明确记录
- [ ] tests + typecheck 通过
