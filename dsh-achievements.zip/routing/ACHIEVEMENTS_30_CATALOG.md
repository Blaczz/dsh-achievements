# Agent Achievements — 30 个行为成就候选库

> 目标：让成就系统不只是统计“做了多少”，而是识别 Agent 的行为风格、调试习惯、工具偏好以及一些很离谱但很好笑的瞬间。

## 推荐发布节奏

- **v0.2 首发：1–10**：优先实现已经与现有整体规划一致、且 SessionState 很容易支撑的核心行为成就。
- **v0.3 第二批：11–20**：加入搜索链、Git/依赖行为、Red→Green 和 Test-Driven。
- **v0.4/实验：21–30**：加入更复杂的序列模式、隐藏彩蛋和环境类成就。

标记为“原规划”的条目来自当前整体规划；其余为基于同一行为成就方向新增的候选。

---

## 01. 🔁 Déjà Vu / 似曾相识

- **ID**: `deja-vu`
- **来源**: 原规划
- **系列**: 编辑行为
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+30 XP`
- **触发条件**: 同一个文件在一个 session 内被 edit ≥ 5 次。
- **Flavor Text**: “我发誓，这次真的只是最后再改一下。”
- **实现难度**: 低
- **依赖**: `file-edit`, `filesEdited[path]`

## 02. 🕳 Rabbit Hole / 兔子洞

- **ID**: `rabbit-hole`
- **来源**: 原规划
- **系列**: 搜索与阅读
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+30 XP`
- **触发条件**: 第一次 edit 发生前，已经读取 ≥ 20 个不同文件。
- **Flavor Text**: “问题一定藏在下一个文件里。”
- **实现难度**: 低
- **依赖**: `file-read`, `firstEditSeq`, edit 前 unique reads

## 03. 💣 YOLO / 先改了再说

- **ID**: `yolo`
- **来源**: 原规划
- **系列**: 编辑行为
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+35 XP`
- **触发条件**: 第一次 test 之前已经修改 ≥ 8 个不同文件。
- **Flavor Text**: “测试？等世界先稳定下来再说。”
- **实现难度**: 中
- **依赖**: `file-edit`, `test-result`, `firstTestSeq`, `editsBeforeFirstTest`

## 04. 🔥 It Works Eventually / 终于能跑了

- **ID**: `it-works-eventually`
- **来源**: 原规划
- **系列**: 测试与调试
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+30 XP`
- **触发条件**: 测试累计失败 ≥ 5 次后，出现一次测试成功。
- **Flavor Text**: “Persistence is a feature.”
- **实现难度**: 中
- **依赖**: `test-result`, failed count, outcome order

## 05. 🎰 Surely This Time / 这次一定

- **ID**: `surely-this-time`
- **来源**: 原规划
- **系列**: 测试与调试
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+35 XP`
- **触发条件**: 完全相同的测试命令连续失败 ≥ 5 次。
- **Flavor Text**: “第六次运行时，宇宙也许会改变主意。”
- **实现难度**: 中
- **依赖**: `test-result`, `command`, consecutive failed command state

## 06. 🎯 One Shot / 一发入魂

- **ID**: `one-shot`
- **来源**: 原规划
- **系列**: 效率流
- **Scope**: `session`
- **Rarity / XP**: `epic` / `+50 XP`
- **触发条件**: session 中只发生 1 次 edit，随后第一次测试直接通过。
- **Flavor Text**: “没有第二枪，因为不需要。”
- **实现难度**: 中
- **依赖**: edit count, first test outcome

## 07. 📚 Librarian / 图书管理员

- **ID**: `librarian`
- **来源**: 原规划
- **系列**: 搜索与阅读
- **Scope**: `session`
- **Rarity / XP**: `uncommon` / `+20 XP`
- **触发条件**: 一个 session 内读取 ≥ 30 个不同文件。
- **Flavor Text**: “整个仓库都借阅过了。”
- **实现难度**: 低
- **依赖**: `file-read`, unique `filesRead`

## 08. 🌱 Touch Grass / 出去走走吧

- **ID**: `touch-grass`
- **来源**: 原规划
- **系列**: 工具使用
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+30 XP`
- **触发条件**: 一个 session 内工具调用达到 100 次。
- **Flavor Text**: “草地不需要 tool call。”
- **实现难度**: 低
- **依赖**: `tool-call`, `session.toolCalls`

## 09. 🦴 Dependency Archaeologist / 依赖考古学家

- **ID**: `dependency-archaeologist`
- **来源**: 原规划
- **系列**: 搜索与阅读
- **Scope**: `session`
- **Rarity / XP**: `epic` / `+50 XP`
- **触发条件**: 读取 `node_modules`、`site-packages` 或 `vendor` 下的文件。
- **Flavor Text**: “你进入了 node_modules，而且活着回来了。”
- **实现难度**: 低
- **依赖**: `file-read`, path classifier

## 10. 🗿 Gigachad / 巨佬模式

- **ID**: `gigachad`
- **来源**: 原规划
- **系列**: 效率流
- **Scope**: `session`
- **Rarity / XP**: `legendary` / `+100 XP`
- **触发条件**: 在 ≤ 5 次工具调用内完成“一次定位/搜索 → 一次 edit → 一次 test”，且测试通过。
- **Flavor Text**: “少说，少看，少改，直接对。”
- **实现难度**: 高
- **依赖**: compact event sequence

## 11. 🔎 Search Party / 搜索队

- **ID**: `search-party`
- **来源**: 原规划扩展链
- **系列**: 搜索与阅读
- **Scope**: `session`
- **Rarity / XP**: `uncommon` / `+20 XP`
- **触发条件**: 一个 session 内执行 search/grep 类操作 ≥ 10 次。
- **Flavor Text**: “先把嫌疑人都叫来。”
- **实现难度**: 低
- **依赖**: search tool classifier

## 12. 🌀 grep -R /dev/soul / 灵魂递归搜索

- **ID**: `grep-dev-soul`
- **来源**: 原规划扩展链
- **系列**: 搜索与阅读
- **Scope**: `lifetime`
- **Rarity / XP**: `epic` / `+75 XP`
- **触发条件**: Lifetime search/grep 类操作达到 500 次。
- **Flavor Text**: “最终发现 bug 在自己心里。”
- **实现难度**: 低
- **依赖**: lifetime search counter

## 13. 🪡 Needle in a Haystack / 海底捞针

- **ID**: `needle-in-a-haystack`
- **来源**: 新增
- **系列**: 搜索与阅读
- **Scope**: `session`
- **Rarity / XP**: `epic` / `+50 XP`
- **触发条件**: edit 前累计 ≥ 15 次 read/search，最终只修改 1 个文件且测试通过。
- **Flavor Text**: “找了半天，问题真的只有一行。”
- **实现难度**: 中
- **依赖**: read/search counters, edit count, test result, event order

## 14. 🦆 Rubber Duck Detective / 橡皮鸭侦探

- **ID**: `rubber-duck-detective`
- **来源**: 新增
- **系列**: 搜索与阅读
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+35 XP`
- **触发条件**: 连续 ≥ 10 次 read/search 且没有 edit，随后第一次 edit 后在 3 个事件内测试通过。
- **Flavor Text**: “鸭子没说话，但它显然知道答案。”
- **实现难度**: 高
- **依赖**: consecutive reads/searches, recent event window

## 15. 🏺 Git Archaeologist / Git 考古学家

- **ID**: `git-archaeologist`
- **来源**: 新增
- **系列**: 版本历史
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+35 XP`
- **触发条件**: 第一次 edit 前执行 `git log` / `git blame` / `git show` 合计 ≥ 8 次。
- **Flavor Text**: “答案不在代码里，在 2022 年的那个 commit 里。”
- **实现难度**: 中
- **依赖**: `shell-command`, git command classifier, `firstEditSeq`

## 16. 🏗️ Renovation Mode / 全屋翻新

- **ID**: `renovation-mode`
- **来源**: 新增
- **系列**: 编辑行为
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+35 XP`
- **触发条件**: 一个 session 内修改 ≥ 12 个不同文件。
- **Flavor Text**: “本来只想修个水龙头。”
- **实现难度**: 低
- **依赖**: unique `filesEdited`

## 17. ⚙️ Config Whisperer / 配置低语者

- **ID**: `config-whisperer`
- **来源**: 新增
- **系列**: 编辑行为
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+35 XP`
- **触发条件**: 只修改配置/manifest 类文件，没有修改源码，随后测试通过。
- **Flavor Text**: “代码没错，世界的配置错了。”
- **实现难度**: 中
- **依赖**: file category classifier, test result

## 18. 📦 Dependency Hell / 依赖地狱

- **ID**: `dependency-hell`
- **来源**: 原规划 Pack 思路扩展
- **系列**: 依赖与环境
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+40 XP`
- **触发条件**: 同一 session 中依赖清单文件被修改 ≥ 3 次，例如 `package.json`、`requirements.txt`、`pyproject.toml`、`Cargo.toml`。
- **Flavor Text**: “升级一个包，获得七个新问题。”
- **实现难度**: 中
- **依赖**: dependency manifest classifier

## 19. 🚦 Red to Green / 红转绿

- **ID**: `red-to-green`
- **来源**: 新增
- **系列**: 测试与调试
- **Scope**: `session`
- **Rarity / XP**: `uncommon` / `+25 XP`
- **触发条件**: 某测试命令失败后，只进行 1 次 edit，再运行相同测试命令并通过。
- **Flavor Text**: “红灯停，改一刀，绿灯行。”
- **实现难度**: 高
- **依赖**: test command/outcome, edit sequence

## 20. 🧪 Test-Driven / 测试先行

- **ID**: `test-driven`
- **来源**: 新增
- **系列**: 测试与调试
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+35 XP`
- **触发条件**: 第一次 edit 前先运行测试且失败；edit 后相同测试命令最终通过。
- **Flavor Text**: “先证明它坏了，再证明你修好了。”
- **实现难度**: 中
- **依赖**: `firstEditSeq`, test command matching

## 21. 🔥 Never Give Up / 永不放弃

- **ID**: `never-give-up`
- **来源**: 原规划扩展链
- **系列**: 测试与调试
- **Scope**: `session`
- **Rarity / XP**: `epic` / `+60 XP`
- **触发条件**: 测试累计失败 ≥ 10 次后终于通过。
- **Flavor Text**: “十次失败只是更详细的日志。”
- **实现难度**: 中
- **依赖**: failed count before pass

## 22. 🌋 Sunk Cost Fallacy / 沉没成本

- **ID**: `sunk-cost-fallacy`
- **来源**: 原规划扩展链
- **系列**: 测试与调试
- **Scope**: `session`
- **Rarity / XP**: `legendary` / `+120 XP`
- **触发条件**: 测试累计失败 ≥ 20 次后终于通过。
- **Flavor Text**: “都已经失败十九次了，现在怎么能停？”
- **实现难度**: 中
- **依赖**: failed count before pass

## 23. 🐈 Schrödinger's Test / 薛定谔的测试

- **ID**: `schrodingers-test`
- **来源**: 新增
- **系列**: 测试与调试
- **Scope**: `session`
- **Rarity / XP**: `legendary` / `+100 XP`
- **触发条件**: 完全相同的测试命令在没有任何 edit 的情况下出现 `fail → pass → fail → pass`。
- **Flavor Text**: “在你观察之前，它既通过又失败。”
- **实现难度**: 高
- **依赖**: test history, command matching, edit sequence

## 24. 🔄 Groundhog Day / 土拨鼠之日

- **ID**: `groundhog-day`
- **来源**: 新增
- **系列**: 测试与调试
- **Scope**: `session`
- **Rarity / XP**: `epic` / `+60 XP`
- **触发条件**: “修改同一文件 → 运行同一测试 → 失败”这一循环连续发生 ≥ 3 次。
- **Flavor Text**: “早上好。还是这个错误。”
- **实现难度**: 高
- **依赖**: recent event history, file path, test command/outcome

## 25. 🛠️ Swiss Army Agent / 瑞士军刀

- **ID**: `swiss-army-agent`
- **来源**: 新增
- **系列**: 工具使用
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+35 XP`
- **触发条件**: 一个 session 内使用 ≥ 8 种不同工具。
- **Flavor Text**: “工具箱里没有吃灰的。”
- **实现难度**: 低
- **依赖**: `toolsByName`

## 26. 🚇 Tunnel Vision / 隧道视野

- **ID**: `tunnel-vision`
- **来源**: 新增
- **系列**: 工具使用
- **Scope**: `session`
- **Rarity / XP**: `rare` / `+30 XP`
- **触发条件**: 一个 session 内工具调用 ≥ 50 次，但只使用 ≤ 2 种工具。
- **Flavor Text**: “当你手里只有 grep，所有问题都像字符串。”
- **实现难度**: 低
- **依赖**: `toolCalls`, `toolsByName`

## 27. 🪶 Minimalist / 极简主义

- **ID**: `minimalist`
- **来源**: 新增
- **系列**: 效率流
- **Scope**: `session`
- **Rarity / XP**: `epic` / `+55 XP`
- **触发条件**: ≤ 8 次工具调用、≤ 2 次 edit，并至少有一次测试成功后结束任务。
- **Flavor Text**: “能不调用的工具，就不调用。”
- **实现难度**: 中
- **依赖**: tool count, edit count, test result, session end

## 28. 🌌 Everything Everywhere All at Once / 全面开花

- **ID**: `everything-everywhere`
- **来源**: 新增
- **系列**: 混合行为
- **Scope**: `session`
- **Rarity / XP**: `epic` / `+60 XP`
- **触发条件**: 同一 session 达到：读取 ≥ 15 个不同文件、修改 ≥ 10 个不同文件、使用 ≥ 5 种工具、运行测试 ≥ 5 次。
- **Flavor Text**: “不是在解决一个问题，是在经历一个宇宙。”
- **实现难度**: 低
- **依赖**: filesRead, filesEdited, toolsByName, tests.runs

## 29. 9️⃣9️⃣ 99 Problems / 九十九个问题

- **ID**: `ninety-nine-problems`
- **来源**: 新增
- **系列**: 隐藏彩蛋
- **Scope**: `session`
- **Rarity / XP**: `epic` / `+49 XP`
- **Hidden**: `true`
- **触发条件**: session 的工具调用数恰好到达 99 时解锁。
- **Flavor Text**: “我有九十九个问题，而 tool call 是其中全部。”
- **实现难度**: 低
- **依赖**: `toolCalls`

## 30. 💻 Works on My Machine / 在我机器上能跑

- **ID**: `works-on-my-machine`
- **来源**: 新增
- **系列**: 依赖与环境
- **Scope**: `session`
- **Rarity / XP**: `epic` / `+60 XP`
- **触发条件**: 测试失败后执行环境/依赖相关命令（install、venv、env、runtime/version 等），期间没有源码 edit，随后相同测试通过。
- **Flavor Text**: “最终发现代码一直都是无辜的。”
- **实现难度**: 高
- **依赖**: shell classifier, environment command classifier, test command/outcome

---

# 推荐首发 10 个

如果只做第一版，我建议优先：

1. Déjà Vu
2. Rabbit Hole
3. YOLO
4. It Works Eventually
5. Surely This Time
6. One Shot
7. Librarian
8. Touch Grass
9. Dependency Archaeologist
10. Gigachad

这 10 个已经能覆盖：

- 重复编辑
- 过度阅读
- 延迟测试
- 失败后成功
- 重复失败
- 一次成功
- 大量阅读
- 超长 session
- 深入依赖
- 极致高效

而且大部分只依赖你已经规划好的 `SessionAchievementState`。

# 推荐 Achievement Chains

## Search Saga

`Search Party → Rabbit Hole → Librarian → grep -R /dev/soul`

## Testing Saga

`It Works Eventually → Never Give Up → Sunk Cost Fallacy`

## Precision Saga

`Red to Green → One Shot → Minimalist → Gigachad`

# 实现建议

- 低难度规则优先只读取 Counter / Map。
- 中难度规则使用 `firstEditSeq` / `firstTestSeq` 等顺序字段。
- 高难度规则不要保存完整 session event log，建议增加一个**最近 20–50 个标准化事件的有限窗口**。
- 所有规则统一读取 `AchievementContext`，不要让 Achievement 自己解析 Harness payload。
- Hidden 成就控制在少数几个，避免用户完全不知道该追什么。
- 正向成就和“反成就”混合：`One Shot / Gigachad` 是奖励，`YOLO / Rabbit Hole / Tunnel Vision` 是带一点吐槽的观察。
