# Task 14 — P6.1 Lifetime Metrics：State + Reducer

| 字段 | 内容 |
|---|---|
| 优先级 | **P6.1 / 核心数据底座** |
| 前置依赖 | Task 13 |
| 核心目标 | 为文件读取、文件修改、测试、累计活跃天数建立真正跨 session 的 Lifetime counters |
| 风险 | 中（持久化兼容 + 统计口径） |
| 主要文件 | `src/state.ts`, `src/reducer.ts`, reducer/state tests |

## 当前问题

`ProfileState` 当前只有：

```ts
xp
unlocked
turns
toolCalls
toolsByName
sessions
currentStreak
longestStreak
lastActiveDay
seenSessions
```

而以下数据只在 `SessionAchievementState`：

```ts
filesRead
filesEdited
tests
commands
```

因为 `sessions` 最多保留 `MAX_SESSIONS = 64`，不能通过 session 聚合得到可靠 lifetime 值。

## 新增 Profile 字段

在 `ProfileState` 增加：

```ts
/** Distinct local calendar days with at least one completed turn. */
activeDays: number
/** Lifetime successful file-read invocations. */
fileReads: number
/** Lifetime successful file-edit invocations. */
fileEdits: number
/** Lifetime test-run invocations. */
testRuns: number
/** Lifetime successful test runs. */
testPasses: number
/** Lifetime failed test runs. */
testFailures: number
```

`createInitialProfile()` 全部初始化为 `0`。

## 统计口径（必须按此实现）

### `activeDays`

只由 `turn-end` 驱动。

规则：

```text
profile.lastActiveDay === null
  → activeDays +1

profile.lastActiveDay === today
  → activeDays 不变

profile.lastActiveDay !== today
  → activeDays +1
```

随后再更新 streak / `lastActiveDay`。

一天中 1 个或 100 个 turn，都只计 1 个 active day。

### `fileReads`

事件满足：

```ts
event.kind === 'tool-call'
event.tool.kind === 'file-read'
event.isError === false
```

时：

```text
profile.fileReads += 1
```

这里统计**成功调用次数**，不是 distinct path 数。

### `fileEdits`

事件满足：

```ts
tool.kind === 'file-edit' && !event.isError
```

时：

```text
profile.fileEdits += 1
```

同一个文件编辑 10 次，应累计 10。

### `testRuns / testPasses / testFailures`

每个：

```ts
tool.kind === 'test-run'
```

都：

```text
testRuns += 1
```

并根据 `isError`：

```text
pass → testPasses += 1
fail → testFailures += 1
```

这与当前 Session `tests.runs/passed/failed` 语义保持一致。

### `toolCalls`

保持现有逻辑：每个标准 settled `tool-call` 都 +1，不论工具类型和成功失败。

## 建议 reducer 结构

不要在每个 switch case 内重复 spread 整个 profile。

可以在 `reduceToolCall()` 中先建立：

```ts
const profile: ProfileState = {
  ...state.profile,
  toolCalls: state.profile.toolCalls + 1,
  toolsByName: increment(state.profile.toolsByName, tool.name),
}
```

然后 switch 根据 `tool.kind` 对 lifetime fields 做增量修改。

最终统一：

```ts
return {
  ...state,
  profile,
  sessions: touchSession(...),
}
```

这样 Session 与 Lifetime 的同一事件口径更容易审查。

## `activeDays` 与 streak 的实现顺序

建议保存旧日值：

```ts
const previousActiveDay = profile.lastActiveDay
```

先根据 `previousActiveDay` 决定 `activeDays` 是否 +1，再执行现有 streak 更新。

不能先把：

```ts
profile.lastActiveDay = today
```

再判断，否则每次都看起来是同一天。

## 执行任务表

| # | 任务 | 输出 | 验收标准 |
|---|---|---|---|
| 1 | 扩展 `ProfileState` | type | 6 个新字段存在 |
| 2 | 更新 `createInitialProfile()` | init | 新状态全为 0 |
| 3 | `turn-end` 累计 `activeDays` | reducer | 同日不重复、跨日 +1 |
| 4 | successful read 累计 `fileReads` | reducer | error read 不累计 |
| 5 | successful edit 累计 `fileEdits` | reducer | error edit 不累计 |
| 6 | test run 累计 runs/pass/fail | reducer | 与 Session tests 同步 |
| 7 | 不改变原有 Session 行为字段 | regression | Rabbit Hole / YOLO / One Shot 等不回归 |

## 必须测试

### Initial State

```text
activeDays = 0
fileReads = 0
fileEdits = 0
testRuns = 0
testPasses = 0
testFailures = 0
```

### Active Days

- 第一次 turn：0 → 1
- 同一天第二次 turn：仍为 1
- 下一天 turn：1 → 2
- 中断几天后 turn：activeDays +1，但 `currentStreak` 重置为 1
- activeDays 不受 session id 是否相同影响

### File Reads

- 成功 read：+1
- 同一路径再次成功 read：再 +1
- 失败 read：+0
- Session distinct files 逻辑仍按原方式工作

### File Edits

- 成功 edit/write：+1
- 同一路径多次编辑逐次累计
- 失败 edit：+0
- `session.edits` 与 `profile.fileEdits` 在成功 edit 上同步增加

### Tests

- pass：runs +1 / passes +1 / failures +0
- fail：runs +1 / passes +0 / failures +1
- shell-command 非测试命令：三者都不变

## State Version 决策

本任务不改变顶层架构：

```ts
{ version: 2, profile, sessions }
```

因此继续使用 `STATE_VERSION = 2`。

理由：这是 v2 内 additive schema evolution，`normalizeV2()` 已承担 forward-tolerant 补默认值职责。

真正的旧状态兼容与 backfill 在 Task 15 单独处理。

## 禁止事项

- 不从 `Object.values(state.sessions)` 实时推导 lifetime counters。
- 不把 distinct file count 当作 lifetime read/edit 次数。
- 不把 failed file read/edit 计入成功次数。
- 不改变 `MAX_SESSIONS` 解决 lifetime 统计问题。
- 不在本任务新增 30 个成就。
- 不手改 `lib/`。

## Definition of Done

- [ ] 6 个 Profile 新字段存在并正确初始化
- [ ] reducer 的实时统计语义全部有单测
- [ ] streak 行为保持正确
- [ ] 现有 Session 行为统计不回归
- [ ] `npm run typecheck` 通过
- [ ] `npm test` 通过
