# Task 12 — P6 Achievement Progression Expansion 总计划

> 目标：在现有 18 个成就、State v2、行为成就引擎、XP/rarity、Achievement Chains、SDK 与 Badge Wall 已完成的基础上，把系统从“少量累计里程碑 + 独立行为彩蛋”升级为“完整长期成长路线 + 行为成就”的双轨体系。

| 字段 | 内容 |
|---|---|
| 优先级 | **P6 / 主线扩展** |
| 阶段 | v0.6 Achievement Progression |
| 前置依赖 | Task 00–11 均已完成 |
| 核心目标 | 7 条 Lifetime 成长线，每条严格覆盖 common → uncommon → rare → epic → legendary |
| 预计新增 | **30 个** Built-in Achievement，18 → 48 |
| 风险 | 中高（状态统计、历史兼容、UI 密度） |
| 核心原则 | **旧成就只增不改；Lifetime 可追溯补发；Session 行为不追溯；规则层仍保持纯函数** |

## 1. 产品结构

P6 完成后，Built-in Achievement 分为两条产品线：

```text
Built-in Achievements
├── Lifetime Progression / 长期成长
│   ├── 回合              5 档
│   ├── 工具调用          5 档
│   ├── 会话              5 档
│   ├── 累计活跃天数      5 档
│   ├── 文件读取次数      5 档
│   ├── 文件修改次数      5 档
│   └── 测试运行次数      5 档
│
└── Special / Behavior / 特殊行为
    ├── ten-turns（旧额外节点）
    ├── streak-3 / streak-7
    ├── Déjà Vu
    ├── Rabbit Hole
    ├── YOLO
    ├── One Shot
    ├── Gigachad
    └── 其余现有 Session 行为成就
```

长期成长负责“持续使用的成长感”，Session 行为负责“Agent 做出特殊行为时的惊喜感”。

## 2. P6 的七条核心成长线

每条核心成长线必须恰好包含 5 个正式节点，并且稀有度顺序固定：

```ts
['common', 'uncommon', 'rare', 'epic', 'legendary']
```

| 系列 | Common | Uncommon | Rare | Epic | Legendary |
|---|---:|---:|---:|---:|---:|
| 回合 | 1 | 25 | 50 | 100 | 500 |
| 工具调用 | 1 | 25 | 100 | 500 | 2000 |
| 会话 | 1 | 10 | 50 | 200 | 500 |
| 累计活跃天数 | 1 | 7 | 30 | 100 | 365 |
| 文件读取次数 | 10 | 100 | 500 | 2500 | 10000 |
| 文件修改次数 | 1 | 10 | 50 | 250 | 1000 |
| 测试运行次数 | 1 | 10 | 50 | 250 | 1000 |

> 注意：`ten-turns`、`streak-3`、`streak-7` 保留，但不作为七条正式五级成长线的必需节点。

## 3. 必须保持的兼容性原则

### 3.1 旧 Achievement ID 不改

以下已发布 ID 及其含义必须保持稳定：

- `first-turn`
- `ten-turns`
- `hundred-turns`
- `first-tool`
- `hundred-tools`
- `ten-sessions`
- `streak-3`
- `streak-7`
- 现有全部 Session 行为成就 ID

不要为了“统一命名”重命名旧 ID。

### 3.2 旧 rarity / XP 不改

历史状态只保存：

```ts
profile.unlocked[id] = unlockTimestamp
profile.xp = totalXp
```

并没有保存每次解锁实际发放的 XP。因此修改旧成就 XP 会导致 UI 元数据与历史实际发放不一致。

**规则：**

- 旧成就的 rarity / XP / threshold 保持不变。
- 新增五级 Milestone 使用新的统一 XP 建议值。

### 3.3 新 Milestone XP 基准

| Rarity | 新增 Milestone XP |
|---|---:|
| common | 10 |
| uncommon | 30 |
| rare | 75 |
| epic | 175 |
| legendary | 400 |

这是“新增 Lifetime Milestone”的默认基准，不强制改写已有成就，也不强制 Session 行为成就遵守。

## 4. 关键架构决策

### 4.1 Lifetime 指标必须落在 `profile`

不能通过遍历 `state.sessions` 计算 Lifetime 文件读取/修改/测试次数。

原因：`touchSession()` 会把 session 桶裁到 `MAX_SESSIONS = 64`，所以 Session 聚合只能用于近期行为，不是可靠 lifetime 数据源。

P6 必须为 `ProfileState` 增加：

```ts
activeDays: number
fileReads: number
fileEdits: number
testRuns: number
testPasses: number
testFailures: number
```

其中前三条成长线继续使用现有：

```ts
turns
toolCalls
sessions
```

### 4.2 `activeDays` 与 streak 分离

- `activeDays`：累计有多少个不同自然日完成过 `turn/end`。
- `currentStreak`：当前连续活跃天数。
- `longestStreak`：历史最长连续活跃天数。

不允许用 `currentStreak` 代替累计活跃天数。

### 4.3 文件/测试统计语义

- `fileReads`：仅成功 `file-read` 调用 +1。
- `fileEdits`：仅成功 `file-edit` 调用 +1。
- `testRuns`：所有 `test-run` 调用 +1。
- `testPasses`：`test-run` 且 `isError === false` +1。
- `testFailures`：`test-run` 且 `isError === true` +1。
- `toolCalls`：保持现有 settled tool invocation 语义，不改变历史定义。

### 4.4 Code Mode 先补统计覆盖

项目当前只消费：

```text
tool/call + tool/result
```

而 Code Mode 内部子调用使用 `tool/code-dispatch`。在大量引入工具/文件/测试累计成就之前，必须先补齐这条事件路径。

### 4.5 Lifetime 新成就允许 silent reconciliation

升级后，如果用户已有：

```text
500 turns
1000 tool calls
```

则新增且已经满足条件的 Lifetime Milestone 应自动补解锁并补 XP。

但必须：

- 不归属当前 session；
- 不弹连续 Toast；
- 不广播 unlock SSE；
- 不伪造历史完成时间，使用 reconciliation 执行时刻作为 unlock timestamp；
- 幂等：第二次启动不重复补 XP。

Session scope 成就不做历史追溯。

## 5. 任务拆分与严格执行顺序

```text
Task 13  P6.0  Code Mode Event Coverage
   ↓
Task 14  P6.1  Lifetime Metrics State + Reducer
   ↓
Task 15  P6.2  State Normalization + Best-effort Backfill
   ↓
Task 16  P6.3  Milestone Framework
   ↓
Task 17  P6.4  Seven Core Milestone Chains / 30 Achievements
   ↓
Task 18  P6.5  Silent Lifetime Reconciliation
   ↓
Task 19  P6.6  Badge Wall Information Architecture
   ↓
Task 20  P6.7  Full Test Matrix + Docs + Release Gate
```

不要让多个 Agent 并行修改 `src/state.ts`、`src/reducer.ts`、`src/achievements.ts`。这些文件是 P6 的冲突热点。

## 6. 每个 Task 的责任边界

| Task | 主要责任 | 主要文件 |
|---|---|---|
| 13 | Code Mode 子调用进入标准事件流 | `src/index.ts`, `src/events.ts`, classifier tests |
| 14 | 新 Lifetime counters 的实时累计 | `src/state.ts`, `src/reducer.ts` |
| 15 | 旧 v2 状态兼容、保守历史补值 | `src/state.ts`, state tests |
| 16 | Milestone helper + progress/target 标准化 | `src/achievements.ts` |
| 17 | 30 个新成就 + 7 条正式成长链 | `src/achievements.ts`, `src/share.ts` |
| 18 | 启动/注册时静默补解锁 | engine + Host wiring |
| 19 | 48 成就下的信息架构与统计展示 | `src/client/badge-panel.tsx`, browser-safe helpers |
| 20 | 全矩阵回归、文档、build/verify | `tests/*`, docs/README as needed |

## 7. 全阶段不变量

实现过程中必须持续满足：

1. `classifier → reducer → evaluate` 三层仍然可独立单测。
2. Achievement 规则永远不直接读取 Harness 原始 payload。
3. `state.ts` 保持 Host-only；Client 只能 `import type`。
4. `gamification.ts` / `profile.ts` / `share.ts` / client helpers 必须保持 browser-safe。
5. `BUILTIN_PACK` 与第三方 Pack 仍走同一 registry。
6. 重复 Achievement ID 仍然抛异常。
7. `profile.unlocked` 仍是全局一次性解锁来源；XP 不重复发放。
8. 分享层仍不读取文件路径与命令字符串。
9. `lib/` 只由 build 重建，不手改。

## 8. P6 总体验收 Gate

P6 完成时必须同时成立：

- [ ] Built-in Achievement 总数为 **48**（除非实现过程中有明确评审批准的目录变更）
- [ ] 七条核心成长线各有 5 个正式节点
- [ ] 每条正式成长线 rarity 严格为 common → uncommon → rare → epic → legendary
- [ ] 新 Lifetime 指标不依赖 64 个 Session 保留窗口
- [ ] Code Mode 子调用会进入统一统计路径
- [ ] 老 v2 状态可直接加载，无字段缺失崩溃
- [ ] 历史可推导数据采用 conservative backfill，不高估
- [ ] 新 Lifetime 成就能静默追溯解锁且不会 Toast storm
- [ ] 原 18 个成就 ID / threshold / XP / rarity 不被破坏
- [ ] Badge Wall 在约 48 个成就时仍可快速理解，不再单一长列表
- [ ] `npm run typecheck` 通过
- [ ] `npm test` 通过
- [ ] `npm run build` 通过浏览器纯度门禁
- [ ] `npm run verify` 通过

## 9. 明确不在 P6 做的事情

为了控制范围，本阶段不做：

- 排行榜 / 账户 / 云同步；
- 赛季 / 每日任务；
- 动态调整 threshold；
- 对旧成就重新定价；
- 把 30 个行为候选库全部实现；
- 把所有 Session 行为成就强行扩成五档；
- 修改 State 顶层 `{ version: 2, profile, sessions }` 架构；
- 为 milestone 引入远端数据库。

## Definition of Done

- [ ] Task 13–20 全部完成
- [ ] 七条正式成长线数据、规则、UI、测试一致
- [ ] 旧用户升级路径可验证
- [ ] 统计语义有测试且有文档
- [ ] P6 没有破坏 SDK、分享隐私边界和 Client bundle 纯度
