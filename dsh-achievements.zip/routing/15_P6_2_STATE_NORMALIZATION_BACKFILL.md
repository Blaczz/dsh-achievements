# Task 15 — P6.2 State Normalization + Conservative Historical Backfill

| 字段 | 内容 |
|---|---|
| 优先级 | **P6.2 / 升级兼容** |
| 前置依赖 | Task 14 |
| 核心目标 | 让 P6 前的 State v2 无损加载，并尽可能从保留的 Session 桶恢复新 Lifetime counters 的“可信下界” |
| 风险 | 中（避免重复计算与高估） |
| 主要文件 | `src/state.ts`, `tests/state.spec.ts` |

## 问题定义

P6 前已经存在大量 persisted：

```json
{
  "version": 2,
  "profile": {
    "turns": 100,
    "toolCalls": 500,
    "sessions": 20
  },
  "sessions": { ... }
}
```

这些旧 v2 JSON 没有：

```text
activeDays
fileReads
fileEdits
testRuns
testPasses
testFailures
```

如果 `normalizeV2()` 只把缺字段补成 0，会让老用户已有的最近行为全部丢失；但如果遍历 retained sessions 恢复，也只能得到最近最多 64 个 session 的数据，因此只能作为**保守下界**，不能宣称完整历史。

## 核心原则

### 1. 有 persisted lifetime 字段时，绝不能重新聚合 Session

一旦新版 state 已保存：

```json
"fileReads": 1234
```

后续 load 必须直接使用这个值。

否则每次加载都可能：

- 覆盖真实 lifetime 值；
- 或错误重复叠加 retained session 数据。

必须先判断字段是否真实存在，而不是单纯 `toNumber()` 后无法区分“缺失”和“保存的 0”。

建议使用：

```ts
Object.prototype.hasOwnProperty.call(profileRaw, 'fileReads')
```

或封装等价 helper。

### 2. 缺字段时才做 best-effort backfill

如果 P6 新字段不存在，允许从**已经 normalize 的 retained sessions**计算下界。

### 3. 只做可证明的数据恢复

不允许从 `toolCalls` 猜测 file read/edit/test 比例。

不允许根据解锁成就反推精确计数。

## Backfill 规则

### `fileReads`

保留 session 中：

```ts
sum(
  Object.values(session.filesRead)
)
```

因为 map value 是同一路径成功读取次数。

### `fileEdits`

保留 session 中：

```ts
sum(
  Object.values(session.filesEdited)
)
```

等价地也可使用 `session.edits`，但必须确认旧 v2 normalize 后二者语义一致。优先从 `filesEdited` map 求和，因为它直接来自每个成功 file-edit 的累计。

### `testRuns`

```ts
sum(session.tests.runs)
```

### `testPasses`

```ts
sum(session.tests.passed)
```

### `testFailures`

```ts
sum(session.tests.failed)
```

### `activeDays`

无法从 retained session 精确恢复自然日，因为 SessionState 不保存日期。

使用可证明的保守下界：

```ts
Math.max(
  profile.currentStreak,
  profile.longestStreak,
  profile.lastActiveDay === null ? 0 : 1,
)
```

说明：

- 一个长度为 N 的真实 streak 至少证明用户活跃过 N 个不同日；
- `longestStreak` 可能大于当前 streak，因此是更好的历史下界；
- 有 `lastActiveDay` 至少证明有 1 个活跃日。

不能从 `seenSessions.length` 推导 active days，因为多个 session 可发生在同一天。

## v1 → v2 Migration

现有 `migrateV1()` 没有 Session buckets，所以新增字段只能保守初始化：

```text
fileReads = 0
fileEdits = 0
testRuns = 0
testPasses = 0
testFailures = 0
activeDays = max(streakDays, lastActiveDay ? 1 : 0)
```

如果 v1 只有 `currentStreak` 等价数据，则不编造其它历史。

## 推荐 normalize 顺序

```text
1. normalize profile 的旧字段
2. normalize sessions
3. 裁剪 sessions 到 MAX_SESSIONS
4. 对每个 P6 新字段：
   - persisted field 存在 → 使用 persisted number
   - 不存在 → 基于 normalize 后 retained sessions/backward facts 计算下界
5. return v2 state
```

先 normalize session 再 backfill，可以复用 `normalizeSession()` 的容错行为。

## 执行任务表

| # | 任务 | 输出 | 验收标准 |
|---|---|---|---|
| 1 | 为新字段增加 presence-aware normalize | state logic | persisted 0 与 missing 可区分 |
| 2 | retained session 聚合 helper | pure helpers | read/edit/test 下界可测试 |
| 3 | activeDays 下界恢复 | normalize | 不高估 |
| 4 | 更新 v1 migration | migration | 新 Profile 字段完整 |
| 5 | 验证二次 load 幂等 | tests | normalize(normalize(state)) 值不变化 |
| 6 | 验证 MAX_SESSIONS 仍生效 | tests | 不为了 backfill 取消裁剪 |

## 必须测试

### 旧 v2 JSON（无 P6 字段）

构造两个 retained sessions：

```text
session A: read 3, edit 2, tests 2 (1 pass / 1 fail)
session B: read 5, edit 1, tests 1 (pass)
```

期望 lower bound：

```text
fileReads = 8
fileEdits = 3
testRuns = 3
testPasses = 2
testFailures = 1
```

### 新 v2 JSON（字段已存在）

即使 retained sessions 求和只有 8：

```json
"fileReads": 500
```

load 后仍必须是：

```text
500
```

### Persisted Zero

如果明确保存：

```json
"fileReads": 0
```

不得因为 Session 有 read 自动改成非 0。

### Active Days

- `currentStreak=3`, `longestStreak=7`, lastActiveDay 非 null → 7
- 两 streak 都 0，但 lastActiveDay 非 null → 1
- 全无历史 → 0

### Idempotency

对 normalize 后的 state 再执行 `migrateState()`：

```text
所有 P6 lifetime counters 保持完全一致
```

## 用户可见语义

历史 backfill 是“可证明下界”，不是完整重建。

不要在 UI 上写“已完整恢复历史文件读取次数”。如果后续文档需要说明，措辞应为：

> 对旧版本状态，新增长期计数会尽可能从仍保留的近期会话恢复；因旧版本未保存完整 lifetime 指标，恢复值可能低于真实历史使用量。

## 禁止事项

- 不从最多 64 个 Session 推导后宣称完整 lifetime。
- 不在字段已存在时再次聚合 session。
- 不修改 `STATE_VERSION` 仅为了 additive fields。
- 不删除 v1 migration。
- 不利用文件路径或命令内容做 migration。
- 不手改 `lib/`。

## Definition of Done

- [ ] P6 前的 v2 state 可以无错误加载
- [ ] 新字段存在时完全尊重 persisted 值
- [ ] 新字段缺失时使用 conservative lower bound
- [ ] activeDays 不被 sessions 数高估
- [ ] normalize/load 幂等
- [ ] state migration tests 全部通过
